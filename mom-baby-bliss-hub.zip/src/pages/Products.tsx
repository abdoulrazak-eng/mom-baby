import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { ProductGrid } from "@/components/ProductGrid";

const Products = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-6xl mx-auto px-6 py-12">
        <h1 className="text-4xl font-bold mb-2">All Products</h1>
        <p className="text-muted-foreground mb-8">
          Everything for mom & baby, thoughtfully curated.
        </p>
        <ProductGrid first={24} />
      </main>
      <Footer />
    </div>
  );
};

export default Products;
