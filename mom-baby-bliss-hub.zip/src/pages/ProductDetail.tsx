import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { PRODUCT_BY_HANDLE_QUERY, storefrontApiRequest } from "@/lib/shopify";
import { useCartStore } from "@/stores/cartStore";

const ProductDetail = () => {
  const { handle } = useParams();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [selectedVariantId, setSelectedVariantId] = useState<string>("");
  const addItem = useCartStore((s) => s.addItem);
  const isLoading = useCartStore((s) => s.isLoading);

  useEffect(() => {
    if (!handle) return;
    storefrontApiRequest(PRODUCT_BY_HANDLE_QUERY, { handle })
      .then((data) => {
        const p = data?.data?.product;
        setProduct(p);
        setSelectedVariantId(p?.variants.edges[0]?.node.id || "");
      })
      .finally(() => setLoading(false));
  }, [handle]);

  const variant = product?.variants.edges.find((v: any) => v.node.id === selectedVariantId)?.node;
  const image = product?.images.edges[0]?.node;

  const handleAdd = async () => {
    if (!variant || !product) return;
    await addItem({
      product: { node: product },
      variantId: variant.id,
      variantTitle: variant.title,
      price: variant.price,
      quantity: 1,
      selectedOptions: variant.selectedOptions || [],
    });
    toast.success("Added to cart", { position: "top-center" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-6xl mx-auto px-6 py-12">
        {loading ? (
          <div className="flex justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : !product ? (
          <div className="text-center py-20">
            <p className="text-muted-foreground">Product not found.</p>
            <Link to="/products" className="text-primary underline mt-4 inline-block">
              Back to products
            </Link>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-12">
            <div className="aspect-square bg-secondary/20 rounded-lg overflow-hidden">
              {image && (
                <img src={image.url} alt={image.altText || product.title} className="w-full h-full object-cover" />
              )}
            </div>
            <div className="space-y-6">
              <h1 className="text-3xl font-bold">{product.title}</h1>
              <p className="text-2xl font-bold text-primary">
                {variant?.price.currencyCode} {parseFloat(variant?.price.amount || "0").toFixed(2)}
              </p>
              <p className="text-muted-foreground whitespace-pre-line">{product.description}</p>

              {product.variants.edges.length > 1 && (
                <div>
                  <label className="text-sm font-medium block mb-2">Variant</label>
                  <select
                    value={selectedVariantId}
                    onChange={(e) => setSelectedVariantId(e.target.value)}
                    className="w-full border border-input rounded-md px-3 py-2 bg-background"
                  >
                    {product.variants.edges.map((v: any) => (
                      <option key={v.node.id} value={v.node.id}>
                        {v.node.title}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <Button onClick={handleAdd} disabled={isLoading || !variant?.availableForSale} size="lg" className="w-full">
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : variant?.availableForSale ? "Add to Cart" : "Sold Out"}
              </Button>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
};

export default ProductDetail;
